export default [
  require('C:\\Users\\EVALD\\OneDrive\\Desktop\\RUPS\\Vaje\\Vaja 3\\gugol\\node_modules\\infima\\dist\\css\\default\\default.css'),
  require('C:\\Users\\EVALD\\OneDrive\\Desktop\\RUPS\\Vaje\\Vaja 3\\gugol\\node_modules\\@docusaurus\\theme-classic\\lib\\prism-include-languages'),
  require('C:\\Users\\EVALD\\OneDrive\\Desktop\\RUPS\\Vaje\\Vaja 3\\gugol\\node_modules\\@docusaurus\\theme-classic\\lib\\nprogress'),
  require('C:\\Users\\EVALD\\OneDrive\\Desktop\\RUPS\\Vaje\\Vaja 3\\gugol\\src\\css\\custom.css'),
];
