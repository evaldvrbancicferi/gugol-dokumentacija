---
slug: first-blog-post
title: Različica 1.0.5
---

```
+ Podpora za iOS.
+ Popravek prikazovanja okvirjev elementov.
+ Posodobitev knjižnice PyQt na različico 5.3.
- Odstranjevanje opcije za belo barvo okvirjev.
```