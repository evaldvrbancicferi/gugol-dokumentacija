---
slug: mdx-blog-post
title: Različica 1.1.0
---

```
+ Podpora za Linux.
+ Posodobitev ukazov za miško.
+ Več opcij za število celic mreže.
```