---
slug: long-blog-post
title: Različica 1.1.2
---

```
+ Sprememba barv uporabniškega vmesnika.
+ Posodobitev knjižnice - 'Pynput'.
- Odstranitev ukaza - 'ugasni računalnik'.
```