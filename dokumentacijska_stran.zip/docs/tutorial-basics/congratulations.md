---
sidebar_position: 6
---

# Uporabniški vmesnik

Uporabniški vmesnik je za projekt precej enostaven saj zahteva, da uporabniku ni v napoti.

Spodaj imamo primer izgleda nastavitev aplikacije:

<img src="https://i.imgur.com/Mx5FnZh.jpeg" width="700px"   />
