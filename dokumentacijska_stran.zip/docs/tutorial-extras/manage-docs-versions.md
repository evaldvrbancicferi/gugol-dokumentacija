---
sidebar_position: 1
---

# Osnovni ukazi

GUGOL podpira precej ukazom za katere ves čas posluša.

Seznam osnovnih ukazov:
- `povečaj okno` - poveča trenutno okno (fullscreen),
- `pomanjšaj okno` - zmanjša trenutno okno,
- `zapri okno` - zapre trenutno fokusirano okno,
- `odpri [ime]` - odpre aplikacije z imenom `ime`,
- `napiši [tekst]` - simulira tipkanje besedila `tekst`,
- `pokaži namizje` - minimizira vsa okna in fokusira namizje.